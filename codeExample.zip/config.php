<?php
/**
 * Created by PhpStorm.
 * User: Ernie Simuro
 * Date: 5/11/16
 * Time: 10:38 AM
 */

// database connect parameters

$dbHost = "localhost";
$dbUser = "root";
$dbPass = "root";
$dbData = "townsquare";

// use the data type to configure the type of date to use
//  currently we only support json and mysql

$dataType = 'json';